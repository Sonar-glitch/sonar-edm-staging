import React from 'react';
import styles from '../styles/SpiderChart.module.css';

const SpiderChart = ({ genres }) => {
  // Error handling: Check if genres is valid
  if (!genres || !Array.isArray(genres) || genres.length === 0) {
    return (
      <div className={styles.spiderChartContainer}>
        <div className={styles.errorMessage}>
          <p>Unable to display genre chart. No genre data available.</p>
        </div>
      </div>
    );
  }

  // Ensure all genres have valid properties
  const validGenres = genres.map(genre => ({
    name: genre.name || 'Unknown',
    score: typeof genre.score === 'number' && !isNaN(genre.score) ? genre.score : 0
  }));

  // Calculate positions for each genre on the spider chart
  const calculatePoints = (genres) => {
    try {
      const points = [];
      const centerX = 150;
      const centerY = 150;
      const radius = 100;
      
      genres.forEach((genre, index) => {
        const angle = (Math.PI * 2 * index) / genres.length;
        const x = centerX + radius * Math.cos(angle) * (genre.score / 100);
        const y = centerY + radius * Math.sin(angle) * (genre.score / 100);
        points.push({ x, y, name: genre.name, score: genre.score });
      });
      
      return points;
    } catch (error) {
      console.error('Error calculating points:', error);
      return [];
    }
  };
  
  // Create SVG path for the spider web
  const createWebPath = (points) => {
    try {
      if (!points || points.length < 3) {
        return '';
      }
      
      let path = '';
      points.forEach((point, index) => {
        if (index === 0) {
          path += `M ${point.x} ${point.y} `;
        } else {
          path += `L ${point.x} ${point.y} `;
        }
      });
      path += 'Z';
      return path;
    } catch (error) {
      console.error('Error creating web path:', error);
      return '';
    }
  };
  
  // Create grid lines for the spider chart
  const createGridLines = (count) => {
    try {
      const lines = [];
      const centerX = 150;
      const centerY = 150;
      const radius = 100;
      
      for (let i = 1; i <= count; i++) {
        const gridPoints = [];
        const gridRadius = (radius * i) / count;
        
        for (let j = 0; j < validGenres.length; j++) {
          const angle = (Math.PI * 2 * j) / validGenres.length;
          const x = centerX + gridRadius * Math.cos(angle);
          const y = centerY + gridRadius * Math.sin(angle);
          gridPoints.push({ x, y });
        }
        
        lines.push(createWebPath(gridPoints));
      }
      
      return lines;
    } catch (error) {
      console.error('Error creating grid lines:', error);
      return [];
    }
  };
  
  // Create axis lines for each genre
  const createAxisLines = () => {
    try {
      const lines = [];
      const centerX = 150;
      const centerY = 150;
      const radius = 100;
      
      validGenres.forEach((genre, index) => {
        const angle = (Math.PI * 2 * index) / validGenres.length;
        const x = centerX + radius * Math.cos(angle);
        const y = centerY + radius * Math.sin(angle);
        lines.push({ x1: centerX, y1: centerY, x2: x, y2: y });
      });
      
      return lines;
    } catch (error) {
      console.error('Error creating axis lines:', error);
      return [];
    }
  };
  
  // Calculate all the necessary data with error handling
  let points = [];
  let webPath = '';
  let gridLines = [];
  let axisLines = [];
  
  try {
    points = calculatePoints(validGenres);
    webPath = createWebPath(points);
    gridLines = createGridLines(3);
    axisLines = createAxisLines();
  } catch (error) {
    console.error('Error in SpiderChart calculations:', error);
  }
  
  // Function to position genre labels to prevent truncation
  const getGenreLabelPosition = (index, totalGenres) => {
    const angle = (Math.PI * 2 * index) / totalGenres;
    // Increased label radius to provide more space for text
    const labelRadius = 140;
    const labelX = 150 + labelRadius * Math.cos(angle);
    const labelY = 150 + labelRadius * Math.sin(angle);
    
    // Determine text anchor based on position in the circle
    let textAnchor = "middle";
    if (angle < Math.PI * 0.25 || angle > Math.PI * 1.75) {
      textAnchor = "start";
    } else if (angle >= Math.PI * 0.75 && angle <= Math.PI * 1.25) {
      textAnchor = "end";
    }
    
    return { labelX, labelY, textAnchor };
  };
  
  // Format genre names to prevent truncation
  const formatGenreName = (name) => {
    if (!name) return '';
    
    // If name is already short, return as is
    if (name.length <= 12) return name;
    
    // Common abbreviations for EDM genres
    const abbreviations = {
      'Progressive': 'Prog',
      'Electronic': 'Elec',
      'Melodic': 'Melo',
      'Techno': 'Tech',
      'House': 'House',
      'Trance': 'Trance',
      'Dubstep': 'Dub',
      'Drum and Bass': 'DnB',
      'Drum & Bass': 'DnB',
      'Future Bass': 'Fut Bass',
      'Tropical': 'Trop',
      'Hardstyle': 'Hard',
      'Underground': 'Undgr'
    };
    
    // Check if we can use a common abbreviation
    for (const [full, abbr] of Object.entries(abbreviations)) {
      if (name.includes(full)) {
        return name.replace(full, abbr);
      }
    }
    
    // If no common abbreviation, truncate with ellipsis
    return name.substring(0, 10) + '...';
  };
  
  return (
    <div className={styles.spiderChartContainer}>
      {points.length > 0 ? (
        <svg viewBox="0 0 300 300" className={styles.spiderChart}>
          {/* Grid lines */}
          {gridLines.map((line, index) => (
            <path
              key={`grid-${index}`}
              d={line}
              className={styles.gridLine}
            />
          ))}
          
          {/* Axis lines */}
          {axisLines.map((line, index) => (
            <line
              key={`axis-${index}`}
              x1={line.x1}
              y1={line.y1}
              x2={line.x2}
              y2={line.y2}
              className={styles.axisLine}
            />
          ))}
          
          {/* Data web */}
          {webPath && (
            <path
              d={webPath}
              className={styles.dataWeb}
            />
          )}
          
          {/* Data points */}
          {points.map((point, index) => (
            <circle
              key={`point-${index}`}
              cx={point.x}
              cy={point.y}
              r="3"
              className={styles.dataPoint}
            />
          ))}
          
          {/* Genre labels with improved positioning */}
          {points.map((point, index) => {
            const { labelX, labelY, textAnchor } = getGenreLabelPosition(index, validGenres.length);
            const formattedName = formatGenreName(point.name);
            
            return (
              <text
                key={`label-${index}`}
                x={labelX}
                y={labelY}
                className={styles.genreLabel}
                textAnchor={textAnchor}
                dominantBaseline="middle"
                fontSize="10"
              >
                {formattedName}
              </text>
            );
          })}
        </svg>
      ) : (
        <div className={styles.errorMessage}>
          <p>Unable to render chart. Please try again later.</p>
        </div>
      )}
      
      <div className={styles.legend}>
        {validGenres.map((genre, index) => (
          <div key={`legend-${index}`} className={styles.legendItem}>
            <span className={styles.legendColor} style={{ backgroundColor: `hsl(${index * (360 / validGenres.length)}, 70%, 40%)` }}></span>
            <span className={styles.legendText}>{genre.name}: {genre.score}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SpiderChart;
